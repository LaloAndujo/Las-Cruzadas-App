// models/User.js
const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    username: { type: String, required: true, unique: true },
    nickname: { type: String, required: true },
    email: { type: String },
    password: { type: String, required: true },
    points: { type: Number, default: 0 },
    profile_picture: { type: String },
    is_admin: { type: Boolean, default: false },
  },
  { timestamps: true }
);

userSchema.methods.toJSON = function () {
  const obj = this.toObject();
  delete obj.password;
  return obj;
};

module.exports = mongoose.model("User", userSchema);
