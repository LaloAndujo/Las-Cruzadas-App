// server.js
require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const session = require("express-session");
const MongoStore = require("connect-mongo");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const cors = require("cors");

const User = require("./models/User");

const app = express();
app.use(express.json());
app.use(cors({ origin: ["http://localhost:5173", "http://localhost:3000"], credentials: true }));

// Session (optional if you use only JWT)
app.use(
  session({
    secret: process.env.SESSION_SECRET || "cruzadas_secret",
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({ mongoUrl: process.env.MONGO_URL }),
    cookie: { maxAge: 1000 * 60 * 60 * 24 },
  })
);

mongoose
  .connect(process.env.MONGO_URL, { dbName: process.env.DB_NAME })
  .then(() => console.log("✅ Mongo connected"))
  .catch((err) => console.error("Mongo error:", err));

function sign(userId) {
  return jwt.sign({ sub: userId }, process.env.JWT_SECRET, { expiresIn: "30d" });
}

function auth(req, res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) return res.status(401).json({ detail: "No token" });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = payload.sub;
    next();
  } catch {
    return res.status(401).json({ detail: "Invalid token" });
  }
}

// Register
app.post("/api/auth/register", async (req, res) => {
  const { username, nickname, password, email } = req.body;
  const exists = await User.findOne({ username });
  if (exists) return res.json({ success: false, error: "Username already taken" });

  const hashed = await bcrypt.hash(password, 10);
  const user = new User({ username, nickname, email, password: hashed, points: 50 });
  await user.save();

  const token = sign(user._id);
  res.json({ access_token: token, token_type: "bearer", user: user.toJSON() });
});

// Login
app.post("/api/auth/login", async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (!user) return res.json({ success: false, error: "User not found" });

  const valid = await bcrypt.compare(password, user.password);
  if (!valid) return res.json({ success: false, error: "Wrong password" });

  const token = sign(user._id);
  res.json({ access_token: token, token_type: "bearer", user: user.toJSON() });
});

// Profile
app.get("/api/users/me", auth, async (req, res) => {
  const user = await User.findById(req.userId).select("-password");
  res.json(user);
});

// Posts (in-memory minimal stub; replace with real model if needed)
let posts = []; // simple in-memory list
app.post("/api/posts", auth, async (req, res) => {
  const user = await User.findById(req.userId);
  const post = {
    id: Math.random().toString(36).slice(2),
    user_id: user.id,
    username: user.username,
    nickname: user.nickname,
    profile_picture: user.profile_picture,
    content: req.body.content || "",
    image: req.body.image || null,
    likes: [],
    like_count: 0,
    created_at: new Date().toISOString(),
    is_liked: false
  };
  posts.unshift(post);
  // award +10
  user.points += 10;
  await user.save();
  res.json(post);
});

app.get("/api/posts", auth, async (req, res) => {
  // mark is_liked for current user
  const withLiked = posts.map(p => ({
    ...p,
    is_liked: p.likes.includes(String(req.userId)),
    like_count: p.likes.length
  }));
  res.json(withLiked);
});

app.post("/api/posts/:id/like", auth, async (req, res) => {
  const user = await User.findById(req.userId);
  const post = posts.find(p => p.id === req.params.id);
  if (!post) return res.status(404).json({ detail: "Post not found" });
  const uid = String(user.id);
  let action = "like";
  if (post.likes.includes(uid)) {
    post.likes = post.likes.filter(x => x !== uid);
    action = "unlike";
    return res.json({ action, like_count: post.likes.length, points_awarded: 0 });
  } else {
    post.likes.push(uid);
    user.points += 2; // +2 per like action
    await user.save();
    return res.json({ action, like_count: post.likes.length, points_awarded: 2 });
  }
});

// Leaderboard
app.get("/api/leaderboard", async (req, res) => {
  const users = await User.find().sort({ points: -1 }).limit(20).select("nickname points profile_picture");
  res.json(users);
});

const PORT = process.env.PORT || 8000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
