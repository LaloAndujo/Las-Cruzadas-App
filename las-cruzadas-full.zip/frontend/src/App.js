import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import axios from 'axios';
import './style.css';

import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import Feed from './components/Feed';
import Profile from './components/Profile';
import Leaderboard from './components/Leaderboard';

const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || 'http://localhost:8000';
const API = `${BACKEND_URL}/api`;

const AuthContext = React.createContext();
export const useAuth = () => React.useContext(AuthContext);

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      axios.defaults.baseURL = API;
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      fetchUserProfile();
    } else {
      setLoading(false);
    }
  }, []);

  const fetchUserProfile = async () => {
    try {
      const res = await axios.get(`/users/me`);
      setUser(res.data);
    } catch (e) {
      localStorage.removeItem('token');
      delete axios.defaults.headers.common['Authorization'];
    } finally {
      setLoading(false);
    }
  };

  const login = async (username, password) => {
    try {
      const res = await axios.post(`${API}/auth/login`, { username, password });
      const { access_token, user: userData } = res.data;
      if (!access_token) return { success: false, error: res.data?.error || 'Login error' };
      localStorage.setItem('token', access_token);
      axios.defaults.headers.common['Authorization'] = `Bearer ${access_token}`;
      setUser(userData);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.response?.data?.detail || 'Login error' };
    }
  };

  const register = async (username, nickname, password, email) => {
    try {
      const res = await axios.post(`${API}/auth/register`, { username, nickname, password, email });
      const { access_token, user: userData } = res.data;
      if (!access_token) return { success: false, error: res.data?.error || 'Register error' };
      localStorage.setItem('token', access_token);
      axios.defaults.headers.common['Authorization'] = `Bearer ${access_token}`;
      setUser(userData);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.response?.data?.detail || 'Register error' };
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    delete axios.defaults.headers.common['Authorization'];
    setUser(null);
  };

  const updateUserPoints = (newPoints) => setUser(prev => ({ ...prev, points: newPoints }));

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading Las Cruzadas...</p>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ user, login, register, logout, updateUserPoints, refreshUser: fetchUserProfile }}>
      <div className="App">
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={user ? <Navigate to="/dashboard" /> : <LoginPage />} />
            <Route path="/dashboard" element={user ? <Dashboard /> : <Navigate to="/login" />} />
            <Route path="/feed" element={user ? <Feed /> : <Navigate to="/login" />} />
            <Route path="/profile" element={user ? <Profile /> : <Navigate to="/login" />} />
            <Route path="/leaderboard" element={user ? <Leaderboard /> : <Navigate to="/login" />} />
            <Route path="/" element={user ? <Navigate to="/dashboard" /> : <Navigate to="/login" />} />
          </Routes>
        </BrowserRouter>
      </div>
    </AuthContext.Provider>
  );
}

export default App;
